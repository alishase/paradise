discover = document.querySelector('.main-button')
addEventListener.discover('click', scrolling)
function scrolling(){
    window.scrollTo({
        top: 700,
        behavior: "smooth"
    });
}

